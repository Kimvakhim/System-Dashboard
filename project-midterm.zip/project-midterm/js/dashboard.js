// block direct access without logging in
if (sessionStorage.getItem("loggedIn") !== "yes") {
  window.location.href = "login.html";
}

const EVERY_N = 3;
const DECIMALS = 2;
const CURRENCY = "$";

const $ = (id) => document.getElementById(id);

let lastRows = [];

function logout() {
  sessionStorage.removeItem("loggedIn");
  window.location.href = "login.html";
}

function FormatDate(start_dt, i) {
  let [day, month, year] = start_dt.split("-").map(Number);
  let date = new Date(2000 + year, month - 1, day);
  date.setMonth(date.getMonth() + i);

  return String(date.getDate()).padStart(2, "0") + "-" +
         String(date.getMonth() + 1).padStart(2, "0") + "-" +
         String(date.getFullYear()).slice(-2);
}

function toDateObj(text) {
  let [d, m, y] = text.split("-").map(Number);
  return new Date(2000 + y, m - 1, d);
}

function buildSchedule(loan, n, rate, mode) {
  let rows = [];
  let balance = loan;
  let payCount = Math.floor(n / EVERY_N) + (n % EVERY_N ? 1 : 0);

  for (let i = 1; i <= n; i++) {
    let principal = 0;
    let interest = 0;

    if (mode === "flat") {
      principal = loan / n;
      interest = loan * rate / 100;

    } else if (mode === "declining") {
      principal = loan / n;
      interest = balance * rate / 100;

    } else {
      interest = balance * rate / 100;

      if (i % EVERY_N === 0 || i === n) {
        principal = loan / payCount;
      }
    }

    balance -= principal;
    rows.push({ no: i, principal: principal, interest: interest });
  }

  return rows;
}

function round(x) {
  let f = Math.pow(10, DECIMALS);
  return Math.round(x * f) / f;
}

function show() {
  let price = Number($("price").value);
  let n = Number($("duration").value);
  let rate = Number($("interest").value);
  let down = Number($("down").value);
  let start = $("startDate").value;
  let mode = $("mode").value;
  let loan = price - down;

  let rows = buildSchedule(loan, n, rate, mode);
  let today = new Date();
  let html = "";
  let sumP = 0, sumI = 0;
  lastRows = [];

  for (let r of rows) {
    let total = r.principal + r.interest;
    let dateText = FormatDate(start, r.no);

    sumP += r.principal;
    sumI += r.interest;

    lastRows.push([r.no, dateText, round(r.principal), round(r.interest), round(total)]);

    let late = toDateObj(dateText) < today;
    let badge = late
      ? "<span class='status status-overdue'>Overdue</span>"
      : "<span class='status status-pending'>Pending</span>";

    html += "<tr>" +
      "<td class='text-center'>" + r.no + "</td>" +
      "<td class='" + (r.no === 1 ? "date-first" : "") + "'>" + dateText + "</td>" +
      "<td class='text-end'>" + round(r.principal) + "</td>" +
      "<td class='text-end'>" + round(r.interest) + "</td>" +
      "<td class='text-end fw-bold'>" + round(total) + "</td>" +
      "<td class='text-center'>" + badge + "</td></tr>";
  }

  $("rows").innerHTML = html;

  $("foot").innerHTML =
    "<tr><td colspan='2' class='text-center'>TOTAL</td>" +
    "<td class='text-end'>" + round(sumP) + "</td>" +
    "<td class='text-end text-warning'>" + round(sumI) + "</td>" +
    "<td class='text-end'>" + round(sumP + sumI) + "</td>" +
    "<td class='text-center small text-muted'>" + n + " Installments</td></tr>";

  $("sLoan").textContent = round(loan);
  $("sPrin").textContent = round(sumP);
  $("sInt").textContent = round(sumI);
  $("sTotal").textContent = round(sumP + sumI);
  $("tableProduct").textContent = $("product").value;
}

function resetDefaults() {
  $("product").value = "";
  $("price").value ="" ;
  $("duration").value ="" ;
  $("interest").value ="";
  $("down").value = "";
  $("startDate").value = "";
  $("mode").value = "";
  show();
}

function exportCSV() {
  let csv = "No,Date Paid,Principal,Interest,Total\n";

  for (let r of lastRows) csv += r.join(",") + "\n";

  let link = document.createElement("a");
  link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  link.download = "schedule.csv";
  link.click();
}

// run once when the dashboard opens
show();
