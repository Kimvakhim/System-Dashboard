const USERNAME = "admin";
const PASSWORD = "1234";

const $ = (id) => document.getElementById(id);

// already signed in? go straight to the dashboard
if (sessionStorage.getItem("loggedIn") === "yes") {
  window.location.href = "dashboard.html";
}

function login(event) {
  event.preventDefault();

  if ($("username").value === USERNAME && $("password").value === PASSWORD) {
    sessionStorage.setItem("loggedIn", "yes");
    window.location.href = "dashboard.html";
  } else {
    $("error").textContent = "Wrong username or password";
  }
}

function togglePassword() {
  let box = $("password");
  box.type = (box.type === "password") ? "text" : "password";
}
